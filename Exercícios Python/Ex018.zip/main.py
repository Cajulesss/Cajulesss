import math
#Faça um programa que leia o comprimento do cateto oposto e do cateto adjacente de um triângulo retângulo, calcule e mostre o comprimento da hipotenusa. (A raiz não está simplificada!)

#print("Bora calcular a hipotenusa?!")

#b = float(input("Digite o valor do cateto adjacente:"))
#c = float(input("Digite o valor do cateto oposto:"))

#b = math.pow(b,2)
#c = math.pow(c,2)
#hipotenusa = (b+c)**2

#print("A hipotenusa é igual a raiz de: {}".format(math.sqrt(hipotenusa)))

#ou utilizar math.hypot(x,y)

print("Bora calcular a hipotenusa?!")

b = float(input("Digite o valor do cateto adjacente:"))
c = float(input("Digite o valor do cateto oposto:"))

#b = math.pow(b,2)
#c = math.pow(c,2)


print("A hipotenusa é igual a: {}".format(math.hypot(b,c)))
