#ex017- Crie um programa ue leia um número real qualquer pelo teclado e mostre na tela a sua porção inteira: (arredondamento pra cima)

import math
print("Oii, tudo bem? Bora saber a porção inteira de um número?!")
digitar = float(input("Digite um número qualquer:"))
print("Parte inteira do número é: {}".format(math.ceil(digitar)))

