#Faça um programa que leia um ângulo qualquer e mostre na tela o valor no seno, cosseno e tangente desse ângulo.

import math

alpha = int(input("Digite o valor do ângulo que deseja calcular:"))

seno = math.sin(alpha)
cosseno = math.cos(alpha)
tangente = math.tan(alpha)

print("O seno de {} é: {}".format(alpha, seno))
print("O cosseno de {} é: {}".format(alpha, cosseno))
print("A tangente de {} é: {}".format(alpha, tangente))

